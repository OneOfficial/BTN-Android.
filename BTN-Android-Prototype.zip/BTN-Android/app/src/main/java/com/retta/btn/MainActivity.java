package com.retta.btn;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bind(R.id.playButton, "PLAY", "Mesin game belum terintegrasi. Tahap berikutnya adalah memastikan jalur integrasi engine yang sah dan dapat diuji.");
        bind(R.id.cheatButton, "CHEAT", "Menu cheat disiapkan. Setiap cheat nantinya memiliki sakelar ON/OFF setelah format dan kompatibilitasnya diuji.");
        bind(R.id.modButton, "MOD MANAGER", "Menu pengelola mod disiapkan. Impor mod dan pemeriksaan kompatibilitas belum aktif.");
        bind(R.id.languageButton, "LANGUAGE", "Pilihan bahasa aplikasi akan ditambahkan. Bahasa dialog di dalam game membutuhkan berkas terjemahan yang kompatibel.");
        bind(R.id.saveButton, "SAVE MANAGER", "Pengelola save akan diaktifkan setelah lokasi dan format penyimpanan engine diketahui.");
        bind(R.id.graphicsButton, "GRAPHICS", "Pengaturan grafis akan mengikuti kemampuan engine. Mode HD tidak otomatis berarti tekstur game sudah HD.");
        bind(R.id.donateButton, "DONATE", "Halaman QRIS akan dipasang setelah aset QRIS final tersedia.");
        findViewById(R.id.youtubeButton).setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@puyyofficial?si=8Du54dR7S_duGfoy"));
            startActivity(i);
        });
    }
    private void bind(int id, String title, String message) {
        Button b = findViewById(id);
        b.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show());
    }
}
