# BTN Android - Prototype 0.1.0

Starter Android project for the BTN app interface. It is a prototype shell, not a playable emulator and not a repackaged ePSXe build.

## Included
- Landscape main menu
- BTN branding and `By : Retta` credit
- Placeholder sections for Play, Cheat, Mod Manager, Language, Save Manager, Graphics, and Donate
- PuyyOFFICIAL YouTube button
- GitHub Actions workflow to build a debug APK

## Build
Open this folder in Android Studio or push it to a GitHub repository and run the `Build BTN APK` workflow. The project uses Android Gradle Plugin 8.7.3, Java 17, compileSdk 35.

## Important
The game engine is not integrated yet. ePSXe native libraries being present in an APK does not establish that they can legally or technically be embedded. Do not include BIOS, game images, or third-party engine binaries in a distributed APK unless you have the applicable redistribution rights. The game ISO should remain user-supplied.
